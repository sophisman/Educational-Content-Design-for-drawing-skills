package com.example.tray;

import android.graphics.Path;

import java.util.ArrayList;
import java.util.List;

public class SVGBuilder {

    private List<Path> pathList = new ArrayList<>();

    public void addPath(Path path) {
        pathList.add(path);
    }

    public String build() {
        StringBuilder svg = new StringBuilder();
        svg.append("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\">\n");

        for (Path path : pathList) {
            svg.append("<path d=\"").append(convertPathToString(path)).append("\"/>\n");
        }

        svg.append("</svg>");
        return svg.toString();
    }
    /*
        for (int i = 0; i < path.getLength(); i++) {
        switch (path.getSegment(i, points)) {
            case Path.SEG_MOVETO:
                pathString.append("M").append(points[0]).append(",").append(points[1]).append(" ");
                break;
            case Path.SEG_LINETO:
                pathString.append("L").append(points[0]).append(",").append(points[1]).append(" ");
                break;
            case Path.SEG_CLOSE:
                pathString.append("Z");
                break;
            default:
                // Other Path segments are not supported
                break;
        }
    }*/
    private String convertPathToString(Path path) {
        StringBuilder pathString = new StringBuilder();
        float[] points = new float[2];

        return pathString.toString().trim();
    }
}
