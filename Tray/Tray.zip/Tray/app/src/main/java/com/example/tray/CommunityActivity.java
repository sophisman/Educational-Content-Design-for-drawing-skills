package com.example.tray;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toolbar;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.firebase.auth.FirebaseAuth;

public class CommunityActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle drawerToggle;
    private FragmentTransaction fragmentTransaction;
    private FragmentManager fragmentManager;
    private MyPageFragment myPageFragment;
    private PostFragment postFragment;
    private RankingFragment rankingFragment;
    private InfoFragment infoFragment;
    private FirebaseAuth mFirebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community);

        // Fragment 객체 생성
        myPageFragment = new MyPageFragment();
        postFragment = new PostFragment();
        rankingFragment = new RankingFragment();
        infoFragment = new InfoFragment();

        // 기본적으로 보여줄 Fragment 설정
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, myPageFragment);
        fragmentTransaction.commit();

        // DrawerLayout 설정
        drawerLayout = findViewById(R.id.drawer_layout);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.drawer_open, R.string.drawer_close);
        drawerLayout.addDrawerListener(drawerToggle);

        // DrawerLayout의 버튼 클릭 시 Fragment 교체
        //마이페이지
        Button btn_mypage = findViewById(R.id.button_mypage);
        btn_mypage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, myPageFragment);
                fragmentTransaction.commit();
                drawerLayout.closeDrawers();
            }
        });


        //창작마당
        Button btn_post = findViewById(R.id.button_post);
        btn_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, postFragment);
                fragmentTransaction.commit();
                drawerLayout.closeDrawers();
            }
        });
        //인기 작품
        Button btn_ranking = findViewById(R.id.button_ranking);
        btn_ranking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, rankingFragment);
                fragmentTransaction.commit();
                drawerLayout.closeDrawers();
            }
        });
        //이용 정보
        Button btn_info = findViewById(R.id.button_info);
        btn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, infoFragment);
                fragmentTransaction.commit();
                drawerLayout.closeDrawers();
            }
        });

        // 로그아웃 버튼 클릭 시 로그아웃
        Button btn_logout = findViewById(R.id.btn_logout);
        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mFirebaseAuth != null) {
                    mFirebaseAuth.signOut();
                }
                Intent intent = new Intent(CommunityActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
   // 위 코드에서 mFirebaseAuth 객체가 null이면 signOut() 메소드를 호출하지 않도록 처리하였음


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}