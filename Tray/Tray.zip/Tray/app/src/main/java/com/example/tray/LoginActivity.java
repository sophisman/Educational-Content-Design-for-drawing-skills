package com.example.tray;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import android.text.Editable;
import android.text.TextWatcher;


public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mFirebaseAuth;      // 파이어베이스 인증 객체
    private DatabaseReference mDatabaseRef;  // 실시간 데이터베이스
    private EditText mEtEmail, mEtPwd;       // 로그인 입력필드
    private Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        FirebaseApp.initializeApp(this);

        mFirebaseAuth = FirebaseAuth.getInstance(); //FirebaseAuth 인스턴스 가져오기
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("TRAY");

        mEtEmail = findViewById(R.id.et_email);
        mEtPwd = findViewById(R.id.et_pwd);
        btn_login = findViewById(R.id.btn_login);
        btn_login.setVisibility(View.GONE);  // 로그인 버튼을 처음에는 보이지 않도록 설정

        // 이메일과 비밀번호 입력 필드의 내용이 변경될 때마다 로그인 버튼을 표시할지 감출지 결정
        mEtEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateLoginButtonVisibility();  // 이메일 입력 필드의 내용이 변경될 때마다 로그인 버튼 표시 여부를 갱신
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        mEtPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateLoginButtonVisibility();  // 비밀번호 입력 필드의 내용이 변경될 때마다 로그인 버튼 표시 여부를 갱신
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 로그인 요청버튼
                String strEmail = mEtEmail.getText().toString();
                String strPwd = mEtPwd.getText().toString();

                mFirebaseAuth.signInWithEmailAndPassword(strEmail, strPwd).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // 로그인 성공
                            Intent intent = new Intent(LoginActivity.this, CommunityActivity.class);
                            startActivity(intent);
                            finish(); // 현재 액티비티 파괴
                        } else {
                            Toast.makeText(LoginActivity.this, "회원정보를 다시 확인해 주세요", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
        // 회원가입 버튼 클릭 리스너 설정
        Button btn_register = findViewById(R.id.btn_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // 회원가입 화면으로 이동
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
                //Log.d("RegisterActivity", "RegisterActivity started"); //로그켓확인용
            }
        });
    }

    // 이메일과 비밀번호 입력 필드가 모두 공란이 아닌 경우에만 로그인 버튼을 표시
    private void updateLoginButtonVisibility() {
        if (mEtEmail.getText().toString().equals("") || mEtPwd.getText().toString().equals("")) {
            btn_login.setVisibility(View.GONE);
        } else {
            btn_login.setVisibility(View.VISIBLE);
        }

    }
}
