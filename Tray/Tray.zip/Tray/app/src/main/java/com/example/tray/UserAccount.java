package com.example.tray;

/*사용자 계정 정보 모델 클래스*/

public class UserAccount {
    private String idToken;  //고유토크정보
    private String emailid;  //이메일
    private String password; //비밀번호

    public UserAccount() {}

    public String getIdToken() {
        return idToken;
    }

    public void setIdToken(String idToken) {
        this.idToken = idToken;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}