package com.example.tray;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.caverock.androidsvg.SVG;
import com.caverock.androidsvg.SVGParseException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;




public class MainDrawingFragment extends Fragment {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final String TAG = "MainDrawingFragment";

    private GuidedDrawingView guidedDrawingView;
    private FreeDrawingView freeDrawingView;
    private Button saveButton;
    private Button deleteButton;

    public MainDrawingFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_drawing, container, false);

        // Initialize views
        guidedDrawingView = view.findViewById(R.id.guided_drawing_view);
        freeDrawingView = view.findViewById(R.id.free_drawing_view);
        saveButton = view.findViewById(R.id.save_button);
        deleteButton = view.findViewById(R.id.delete_button);

        saveButton.setText("Save SVG"); // 버튼 텍스트를 "Save SVG"로 변경

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSvgDrawing();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteDrawing();
            }
        });

        return view;
    }

    private void saveSvgDrawing() {
        SVG svg = null;
        try {
            svg = SVG.getFromString(freeDrawingView.getVectorDrawable());
        } catch (SVGParseException e) {
            e.printStackTrace();
            Toast.makeText(getActivity(), "Failed to save SVG", Toast.LENGTH_LONG).show();
            return;
        }
        String svgString = svg.toString();
        try {
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "drawing.svg");
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            osw.write(svgString);
            osw.flush();
            osw.close();
            Toast.makeText(getActivity(), "Drawing saved as SVG", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(getActivity(), "Failed to save SVG", Toast.LENGTH_LONG).show();
        }
    }



    private void deleteDrawing() {
        freeDrawingView.deleteImage();
        Toast.makeText(getActivity(), "Drawing deleted", Toast.LENGTH_LONG).show();
    }

}
