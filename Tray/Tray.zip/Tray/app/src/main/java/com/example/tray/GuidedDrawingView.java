package com.example.tray;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;

import java.util.ArrayList;
import java.util.List;

public class GuidedDrawingView extends androidx.appcompat.widget.AppCompatImageView {

    private List<PointF> guidePoints;
    private Paint guidePaint;
    private boolean isDrawingGuide;
    private int guideIndex;
    private float touchTolerance;

    public GuidedDrawingView(Context context) {
        super(context);
        init();
    }

    public GuidedDrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        guidePoints = new ArrayList<>();
        guidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        guidePaint.setStyle(Paint.Style.STROKE);
        guidePaint.setStrokeWidth(5);
        guidePaint.setColor(Color.GRAY);
        touchTolerance = ViewConfiguration.get(getContext()).getScaledTouchSlop();
    }

    public void setGuidePoints(List<PointF> guidePoints) {
        this.guidePoints = guidePoints;
        invalidate();
    }



    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (isDrawingGuide) {
            for (int i = 0; i < guideIndex; i++) {
                PointF p = guidePoints.get(i);
                canvas.drawPoint(p.x, p.y, guidePaint);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                handleTouchDown(event);
                return true;
            case MotionEvent.ACTION_MOVE:
                handleTouchMove(event);
                return true;
            case MotionEvent.ACTION_UP:
                handleTouchUp(event);
                return true;
        }
        return super.onTouchEvent(event);
    }

    private void handleTouchDown(MotionEvent event) {
        if (!guidePoints.isEmpty()) {
            isDrawingGuide = true;
            guideIndex = 0;
            invalidate();
        }
    }

    private void handleTouchMove(MotionEvent event) {
        if (isDrawingGuide) {
            PointF currentPoint = new PointF(event.getX(), event.getY());
            PointF lastPoint = guidePoints.get(guideIndex);
            if (distance(currentPoint, lastPoint) > touchTolerance) {
                guideIndex++;
                invalidate();
            }
        }
    }

    private void handleTouchUp(MotionEvent event) {
        isDrawingGuide = false;
        invalidate();
    }

    private float distance(PointF p1, PointF p2) {
        float dx = p2.x - p1.x;
        float dy = p2.y - p1.y;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }
}
