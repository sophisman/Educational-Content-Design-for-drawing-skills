package com.example.tray;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class GuideTracingActivity extends AppCompatActivity {
    private ImageView imageView;
    private Bitmap bitmap;
    private Canvas canvas;
    private Paint paint;
    private List<Point> guidePoints;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_tracing);

        // ImageView 초기화
        imageView = findViewById(R.id.imageView);

        // Bitmap 초기화
        bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.apple).copy(Bitmap.Config.ARGB_8888, true);

        // Canvas 초기화
        canvas = new Canvas(bitmap);

        // Paint 초기화
        paint = new Paint();
        paint.setColor(Color.GRAY);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5);

        // 가이드 포인트 초기화
        guidePoints = new ArrayList<>();
        guidePoints.add(new Point(50, 50));
        guidePoints.add(new Point(200, 200));
        guidePoints.add(new Point(300, 100));

        // Canvas에 가이드 포인트 그리기
        Path path = new Path();
        for (int i = 0; i < guidePoints.size(); i++) {
            Point point = guidePoints.get(i);
            if (i == 0) {
                path.moveTo(point.x, point.y);
            } else {
                path.lineTo(point.x, point.y);
            }
        }
        canvas.drawPath(path, paint);

        // ImageView에 Bitmap 설정
        imageView.setImageBitmap(bitmap);

        // ImageView의 Touch 이벤트 처리
        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        break;
                    case MotionEvent.ACTION_MOVE:
                        // 현재 마우스 위치 계산
                        int x = (int) event.getX();
                        int y = (int) event.getY();

                        // 가이드 포인트와의 거리 계산
                        double minDistance = Double.MAX_VALUE;
                        Point closestPoint = null;
                        for (Point point : guidePoints) {
                            double distance = Math.sqrt(Math.pow(x - point.x, 2) + Math.pow(y - point.y, 2));
                            if (distance < minDistance) {
                                minDistance = distance;
                                closestPoint = point;
                            }
                        }

                        // Canvas에 가이드 라인 그리기
                        canvas.drawLine(closestPoint.x, closestPoint.y, x, y, paint);

                        // ImageView 업데이트
                        imageView.invalidate();
                        break;
                    case MotionEvent.ACTION_UP:
                        break;
                }
                return true;
            }
        });
    }
}