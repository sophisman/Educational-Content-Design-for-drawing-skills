package com.example.tray;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.caverock.androidsvg.SVG;
import com.caverock.androidsvg.SVGParseException;

import java.io.IOException;


public class MainDrawingActivity extends AppCompatActivity {

    private Bitmap bitmap;
    private Canvas canvas;
    private Paint paint;
    private ImageView imageView;
    private View guideView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        imageView = findViewById(R.id.image_view);
        guideView = findViewById(R.id.guide_view);

        // SVG 파일 로드
        SVG svg = null;
        try {
            svg = SVG.getFromInputStream(getAssets().open("bee.svg"));
        } catch (IOException | SVGParseException e) {
            e.printStackTrace();
        }



        // SVG 이미지를 비트맵으로 변환
        bitmap = Bitmap.createBitmap((int)svg.getDocumentWidth(), (int)svg.getDocumentHeight(), Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        canvas.drawRGB(255, 255, 255); // 배경색 설정
        svg.renderToCanvas(canvas);

        // 이미지뷰에 비트맵 설정
        imageView.setImageBitmap(bitmap);

        guideView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int x = (int) event.getX();
                int y = (int) event.getY();

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // 손가락이 화면에 닿았을 때 처리할 작업
                        break;
                    case MotionEvent.ACTION_MOVE:
                        // 손가락이 화면을 이동할 때 처리할 작업
                        break;
                    case MotionEvent.ACTION_UP:
                        // 손가락이 화면에서 떨어질 때 처리할 작업
                        break;
                }

                return true;
            }
        });
    }
}
