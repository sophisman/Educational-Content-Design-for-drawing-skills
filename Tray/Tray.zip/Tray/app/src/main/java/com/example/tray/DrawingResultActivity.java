package com.example.tray;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;

public class DrawingResultActivity extends AppCompatActivity {

    private ImageView resultImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        resultImageView = findViewById(R.id.image_view);

        Bitmap bitmap = getIntent().getParcelableExtra("bitmap");
        resultImageView.setImageBitmap(bitmap);

        Button doneButton = findViewById(R.id.done_button);
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 결과 이미지를 ByteArray 형태로 변환하여 인텐트에 추가
                BitmapDrawable drawable = (BitmapDrawable) resultImageView.getDrawable();
                Bitmap bitmap = drawable.getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                byte[] byteArray = stream.toByteArray();

                Intent intent = new Intent();
                intent.putExtra("result", byteArray);
                setResult(RESULT_OK, intent);

                finish();
            }
        });
    }
}
