package com.example.tray;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

public class PostFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_post, container, false);
        // PostFragment의 레이아웃 파일인 fragment_post.xml을 inflate하여 View 객체로 반환합니다.

        // 여기에 PostFragment의 코드를 작성합니다.

        return view;
    }
}
