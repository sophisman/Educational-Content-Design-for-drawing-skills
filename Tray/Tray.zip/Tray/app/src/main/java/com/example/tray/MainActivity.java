package com.example.tray;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ScrollView scrollView;
    private RelativeLayout categoryLayout;
    private ImageView categoryImageView;
    private boolean isCategoryVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 뷰 찾기
        ImageView imageView = findViewById(R.id.logo_imageview);

        // 페이드 인 효과
        ObjectAnimator fadeIn = ObjectAnimator.ofFloat(imageView, View.ALPHA, 0f, 1f);
        fadeIn.setDuration(1000); // 1초 동안 애니메이션 실행

        // 애니메이션 시작
        fadeIn.start();

        // 3초 뒤에 SearchActivity로 이동
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, SearchActivity.class);
                startActivity(intent);
                finish();
            }
        }, 1000);
    }
}