package com.example.tray;

public class RandomtemplateActivity {
}
