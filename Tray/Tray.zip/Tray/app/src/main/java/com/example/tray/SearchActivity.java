package com.example.tray;

// SearchActivity: 검색창 액티비티

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SearchActivity extends AppCompatActivity {

    //변수 선언
    private EditText searchEditText; // 검색창에 입력하는 EditText
    private Button searchButton; // 검색 버튼
    private TextView trayLogoText; // trayLogoText
    private FrameLayout categoryLayout; // 카테고리를 담은 RelativeLayout
    private ImageButton communityButton;
    private RelativeLayout communityButtonAll;
    private LinearLayout searchcontainer; // 검색창 전체
    private TextView trayLogoTextSub;
    private ImageView tmpl1Click;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //변수에 할당
        setContentView(R.layout.activity_search); // SearchActivity의 레이아웃 설정
        searchEditText = findViewById(R.id.search_edittext); // "EditText" 레이아웃에서 찾아 변수에 할당
        searchButton = findViewById(R.id.search_button); // "버튼" 레이아웃에서 찾아 변수에 할당
        trayLogoText = findViewById(R.id.tray_logo_text); // "trayLogo" 레이아웃에서 찾아 변수에 할당
        categoryLayout = findViewById(R.id.category_layout); // "categoryLayout" 레이아웃에서 찾아 변수에 할당
        communityButton = findViewById(R.id.community_button);
        communityButtonAll = findViewById(R.id.community_button_all);
        searchcontainer = findViewById(R.id.search_container); // 검색창 전체 변수할당(애니메이션 먹일려고)
        trayLogoTextSub = findViewById(R.id.tray_logo_text_sub);

// EditText의 상태를 체크하는 Listener를 등록합니다.
        searchEditText.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            boolean isOpened = false;
            Animation fadeInAnimation, fadeOutAnimation;

            @Override
            public void onGlobalLayout() {
                Rect r = new Rect();
                searchEditText.getWindowVisibleDisplayFrame(r);

                // 메인화면 랜덤 템플릿 + 검색기능 애니메이션 + 검색창 클릭시 위로 튀는 애니메이션////////////////////////////////////////////////////////////////////
                // 키보드가 올라온 경우
                if (getWindow().getDecorView().getHeight() - r.bottom > 200) { // 200은 임의로 정한 값
                    // 카테고리 레이아웃이 열려있지 않은 경우
                    if (!isOpened) {

                        // 애니메이션 적용
                        Animation animation = AnimationUtils.loadAnimation(SearchActivity.this, R.anim.search_anim);
                        searchcontainer.startAnimation(animation);

                        trayLogoText.clearAnimation(); // 이전에 적용된 애니메이션을 초기화합니다.
                        trayLogoText.setVisibility(View.VISIBLE); // 로고 텍스트를 표시합니다.
                        fadeInAnimation = AnimationUtils.loadAnimation(SearchActivity.this, R.anim.fade_in); // 페이드 인 애니메이션을 가져와 변수에 저장합니다.
                        trayLogoText.startAnimation(fadeInAnimation); // 로고 텍스트에 페이드 인 애니메이션을 적용합니다.
                        categoryLayout.clearAnimation(); // 카테고리 레이아웃에 적용된 애니메이션을 초기화합니다.
                        communityButtonAll.clearAnimation(); // 커뮤니티버튼에 적용된 애니메이션을 초기화합니다.
                        fadeOutAnimation = AnimationUtils.loadAnimation(SearchActivity.this, R.anim.fade_out); // 페이드 아웃 애니메이션을 가져와 변수에 저장합니다.
                        fadeOutAnimation.setAnimationListener(new Animation.AnimationListener() {
                            @Override
                            public void onAnimationStart(Animation animation) { //애니메이션이 시작할때
                                communityButtonAll.setVisibility(View.INVISIBLE); // 창작마당 버튼을 숨깁니다.

                            }

                            @Override
                            public void onAnimationEnd(Animation animation) {//애니메이션이 끝날 때
                                categoryLayout.setVisibility(View.INVISIBLE); // 애니메이션이 끝나면 카테고리 레이아웃을 숨깁니다.

                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {}
                        });
                        categoryLayout.startAnimation(fadeOutAnimation); // 카테고리 레이아웃에 페이드 아웃 애니메이션을 적용합니다.
                        isOpened = true; // 카테고리 레이아웃이 열렸다는 표시를 합니다.
                        //////////////////////////////////////////////////////////////////////////////////////////////
                        //트레이 서브 로고 애니메이션
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                trayLogoTextSub.clearAnimation(); // 이전에 적용된 애니메이션을 초기화합니다.
                                trayLogoTextSub.setVisibility(View.VISIBLE); // 서브로고 텍스트를 보여줍니다.
                                fadeInAnimation = AnimationUtils.loadAnimation(SearchActivity.this, R.anim.fade_in); // 페이드 인 애니메이션을 가져와 변수에 저장합니다.
                                trayLogoTextSub.startAnimation(fadeInAnimation); // 서브로고 텍스트에 페이드 인 애니메이션을 적용합니다.
                            }
                        }, 1000); // 1초 뒤에 실행됩니다.
                        //////////////////////////////////////////////////////////////////////////////////////////////
                    }
                } else { // 키보드가 내려간 경우
                    // 카테고리 레이아웃이 열려있는 경우
                    if (isOpened) {
                        trayLogoText.setVisibility(View.INVISIBLE); // 로고 텍스트를 숨깁니다.
                        trayLogoTextSub.clearAnimation(); // 서브로고 텍스트 애니메이션을 초기화합니다.
                        trayLogoTextSub.setVisibility(View.INVISIBLE); // 서브로고 텍스트를 숨깁니다.
                        categoryLayout.clearAnimation(); // 카테고리 레이아웃에 적용된 애니메이션을 초기화합니다.
                        communityButtonAll.clearAnimation(); // 커뮤니티버튼에 적용된 애니메이션을 초기화합니다.
                        fadeInAnimation = AnimationUtils.loadAnimation(SearchActivity.this, R.anim.fade_in); // 페이드 인 애니메이션을 가져와 변수에 저장합니다.
                        fadeInAnimation.setAnimationListener(new Animation.AnimationListener() {
                            @Override
                            public void onAnimationStart(Animation animation) {}

                            @Override
                            public void onAnimationEnd(Animation animation) {//애니메이션이 끝날 때
                                categoryLayout.setVisibility(View.VISIBLE); // 애니메이션이 끝나면 카테고리 레이아웃을 보여줍니다.
                                communityButtonAll.setVisibility(View.VISIBLE); // 창작마당 버튼을 표시합니다.
                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {}
                        });
                        categoryLayout.startAnimation(fadeInAnimation); // 카테고리 레이아웃에 fade in 애니메이션 적용
                        communityButtonAll.startAnimation(fadeInAnimation); // 창작마당 버튼에 fade in 애니메이션 적용
                        isOpened = false; // 키보드가 내려갔으므로 isOpened 상태를 false로 변경
                    }
                }
                /////////////////////////////////////////////////////////////////////////////////////////////////
            }
        });

// 원하는 템플릿을 클릭 했을 때 (1번만 해봤음)
        tmpl1Click = findViewById(R.id.tmpl1);
        tmpl1Click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ResultActivity.class);
                startActivity(intent);
            }
        });



// 창작마당 버튼을 클릭했을 때
        communityButton = findViewById(R.id.community_button);
        communityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });

// EditText에서 엔터키를 눌렀을 때 검색 기능 수행
        searchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    performSearch(); // 검색 기능 수행 메서드 호출
                    return true;
                }
                return false;
            }

            private void performSearch() { // 검색 기능 수행 메서드
                String query = searchEditText.getText().toString();
                // 검색어를 가져와서 처리하는 코드 작성
                // ...
            }

        });

// 카테고리 레이아웃이 로고 뒤에 위치하도록 함
        categoryLayout.bringToFront();

// 검색 버튼 클릭 이벤트 처리
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 검색어 가져오기
                String searchText = searchEditText.getText().toString().trim();

                if (!TextUtils.isEmpty(searchText)) {
                    // 검색어가 입력되어 있으면 검색 결과 화면으로 이동
                    Intent intent = new Intent(SearchActivity.this, ResultActivity.class);
                    intent.putExtra("searchText", searchText); // 검색어 전달
                    startActivity(intent);

                } else {
                    // 검색어가 입력되어 있지 않으면 Toast 메시지 출력
                    Toast.makeText(getApplicationContext(), "검색어를 입력해주세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });








        // 카테고리 레이아웃이 로고 뒤에 위치하도록 함
        categoryLayout.bringToFront();
    }
}
